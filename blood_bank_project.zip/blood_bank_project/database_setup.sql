-- =============================================
-- Blood Bank Management System - Database Setup
-- =============================================

-- Step 1: Create the database
CREATE DATABASE IF NOT EXISTS blood_bank;
USE blood_bank;

-- Step 2: Create tables

-- Admin table
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL
);

-- Donors table
CREATE TABLE IF NOT EXISTS donors (
    donor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    dob DATE NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(10) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    phone VARCHAR(15) NOT NULL
);

-- Inventory table
CREATE TABLE IF NOT EXISTS inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    blood_group VARCHAR(5) UNIQUE NOT NULL,
    units INT NOT NULL DEFAULT 0
);

-- Blood Requests table
CREATE TABLE IF NOT EXISTS blood_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(100) NOT NULL,
    hospital_name VARCHAR(100) NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    units_required INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Pending'
);

-- Donations table
CREATE TABLE IF NOT EXISTS donations (
    donation_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT NOT NULL,
    blood_group VARCHAR(5) NOT NULL,
    units INT NOT NULL,
    donation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donors(donor_id)
);

-- Step 3: Insert sample admin users
INSERT INTO admin (username, password) VALUES
('admin', 'admin123'),
('nayan', 'nayan1214');

-- Step 4: Insert initial inventory for all blood groups
INSERT INTO inventory (blood_group, units) VALUES
('A+', 10),
('A-', 5),
('B+', 8),
('B-', 3),
('O+', 15),
('O-', 7),
('AB+', 6),
('AB-', 2);
